package com.example.prodan

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.prodan.data.petList
import com.example.prodan.databinding.FragmentHomeBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var privacyPolicy = false
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {

        loadData()
        if(privacyPolicy == false){
            val mBuilder = AlertDialog.Builder(activity)
                .setTitle("AVISO DE PRIVACIDAD")
                .setMessage("Prodefensa Animal A.C., con domicilio en Plutarco Elías Calles 307, Tampiquito, 66240 San Pedro Garza García, N.L., es el responsable del uso y protección de sus datos personales, y al respecto le informamos lo siguiente:\n" +
                        "\n" +
                        "¿Para qué fines utilizaremos sus datos personales?\n\n" +
                        "Los datos personales que recabamos de usted, los utilizaremos para las siguientes finalidades que son necesarias para el servicio que solicita:\n" +
                        "\n" +
                        "Respuesta a mensajes del formulario de contacto\n" +
                        "\n" +
                        "¿Dónde puedo consultar el aviso de privacidad integral?\n\n" +
                        "Para conocer mayor información sobre los términos y condiciones en que serán tratados sus datos personales, como los terceros con quienes compartimos su información personal y la forma en que podrá ejercer sus derechos ARCO, puede consultar el aviso de privacidad integral con una petición vía correo electrónico:\n" +
                        "\n" +
                        "informes@prodan.org.mx\n\n" +
                        "Última actualización de este aviso de privacidad: 29/09/2022\n")
                .setPositiveButton("ACEPTAR"){dialog, which ->
                    saveData()
                }
                .setCancelable(false)

            val mAlertDialog = mBuilder.create()
            mAlertDialog.show()
        }

        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.imageViewOptions.setOnClickListener {
            //Navegación por ID
            Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_optionsFragment)
        }
        // Creando instancia de adaptador
        val adapter = adapter(requireActivity(), petList){
            val bundle = Bundle()
            bundle.putParcelable("pets",it)
            findNavController().navigate(R.id.action_homeFragment_to_detailsFragment,bundle)
        }

        binding.rvpets.adapter = adapter
        binding.rvpets.layoutManager =
            GridLayoutManager(requireActivity(),
                2, RecyclerView.VERTICAL, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment HomeFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            HomeFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    private fun saveData() {

        val acceptedPolicy = true

        val sharedPreferences = requireActivity().getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.apply{
            putBoolean("BOOL_KEY", acceptedPolicy)
        }.apply()
    }

    private fun loadData() {
        val sharedPreferences = requireActivity().getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val savedBool = sharedPreferences.getBoolean("BOOL_KEY", null == true)

        privacyPolicy = savedBool

    }
}