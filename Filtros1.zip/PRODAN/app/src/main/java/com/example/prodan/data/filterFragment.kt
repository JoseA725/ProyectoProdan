package com.example.prodan.data

class filterFragment {
}