package com.example.prodan.data

import com.example.prodan.R

var petList = mutableListOf(
    pets(
        "123",
        "Pingo",
        "https://pngimg.com/uploads/dog/dog_PNG50318.png",
        "6 años",
        R.drawable.boy,
        "Perro",
        "Me gusta jugar mucho en el parque y convivir con otros perros",
        "Pug"
    ),
    pets(
        "124",
        "Lala",
        "https://pngimg.com/uploads/dog/dog_PNG50302.png",
        "3 años",
        R.drawable.girl,
        "Lala",
        "Me asustan los ruidos fuertes",
        "Golden Retriever"
    ),
    pets(
        "125",
        "Mittens",
        "https://pngimg.com/uploads/cat/cat_PNG1621.png",
        "2 años",
        R.drawable.girl,
        "Gato",
        "Me gusta mirarte mientras duermes",
        "Gato negro"
    ),
    pets(
        "126",
        "Garfield",
        "https://pngimg.com/uploads/cat/cat_PNG50487.png",
        "4 años",
        R.drawable.boy,
        "Gato",
        "Me gusta la lasagna",
        "Gato naranja"
    ),
    pets(
        "127",
        "Pedro",
        "https://pngimg.com/uploads/dog/dog_PNG50368.png",
        "6 años",
        R.drawable.boy,
        "Perro",
        "Soy algo gruñon pero no muerdo",
        "Bulldog"
    ),
    pets(
        "128",
        "Pablo",
        "https://pngimg.com/uploads/dog/dog_PNG50325.png",
        "6 años",
        R.drawable.boy,
        "Perro",
        "También soy algo gruñon pero tampoco muerdo",
        "Bulldog"
    ),
    pets(
        "129",
        "Muffin",
        "https://pngimg.com/uploads/cat/cat_PNG50492.png",
        "1 año",
        R.drawable.girl,
        "Gato",
        "No me gusta que agarren de mi comida",
        "Gata gris"
    ),
    pets(
        "130",
        "Kal",
        "https://pngimg.com/uploads/dog/dog_PNG50362.png",
        "8 años",
        R.drawable.boy,
        "Perro",

        "Soy muy fiel y te defiendo a toda madre (el que se meta contigo se muere)",
        "Pastor Alemán"
    ))